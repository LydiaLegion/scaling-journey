---
title: 'Home'
date: 2018-02-12T15:37:57+07:00
heroHeading: 'Hero - Hugo Small Business Theme'
heroSubHeading: 'Hero is a multipurpose Hugo theme with fullscreen hero images and fullwidth sections. It contains content types for a business or portfolio site.'
heroBackground: 'images/jason-blackeye-1191801-unsplash.jpg'
---
