---
title: 'History'
date: 2018-12-06T09:29:16+10:00
draft: false
---

# About Heading

{{< content-strip-left "/pages/history" "content1" >}}
{{< content-strip-right "/pages/about" "content2" >}}
{{< content-strip-center "/pages/about" "content3" >}}
